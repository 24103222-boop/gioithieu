INTRODUCE YOURSELF — OPTIONAL PRESENTATION

This folder contains a short presentation script and submission comment for the optional
"Introduce Yourself" peer-graded practice assignment.

IMPORTANT:
- This ZIP is a supporting document, not a video recording.
- If the submission form requires a video file, record a video under 3 minutes and upload it separately.
- If a URL is required, enter the link to your hosted video or project. Do not use a made-up URL.

Suggested project title:
Introduce Myself – Responsive Web Design

Suggested comments:
Hello, my name is Thuat. I am a student learning web design and development.
In this presentation, I introduce myself and share what I have learned about responsive
web design, including mobile, tablet, and desktop layouts. I also explain how websites can
adapt to user preferences, such as dark mode and reduced motion. Thank you for watching!
